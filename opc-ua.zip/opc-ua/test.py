from iolink.iodd_scraping import iodd_scraper
from pprint import pprint
from coretigo.coretigo_helpers import find_active_nodes
import asyncio
from asyncua import Client, Node, ua
import logging

logging.basicConfig(level=logging.WARNING)

async def main():
    async with Client("opc.tcp://192.168.10.10:4840") as client:
        node: Node = client.get_node("ns=2;i=2")
        await node.call_method(ua.NodeId(Identifier=2, NamespaceIndex=2), 2, 2)

asyncio.run(main())

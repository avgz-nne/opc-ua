import asyncio
import logging
from pprint import pprint
import time

from asyncua import Client

from coretigo.coretigo_helpers import find_active_nodes, convert_values
from iolink.iodd_scraping import iodd_scraper
from iolink.iodd import IODD


async def reader(nodes, iodds):
    all_values = []
    byte_values = await asyncio.gather(
        *[node.read_value() for node in nodes]
    )
    for iodd, v in zip(iodds, byte_values):
        all_values.append(convert_values(iodd, v))

    return all_values


async def writer(node, data, nsidx, nodeidx):
    nodeid = f"ns={nsidx};i={nodeidx}"
    node.write_value(data)


async def main():
    coretigo_url = "opc.tcp://192.168.10.100:4840"
    unibio_url = "opc.tcp://admin@192.168.10.10:4840/nne_unibio/server"

    unibio_nsidx = 2
    unibio_nodeidxs = [2, 3, 4, 5]

    active_bridges = await find_active_nodes(url = coretigo_url)
    iodds = iodd_scraper(sensors=[d["sensor"] for d in active_bridges])
    async with Client(url=coretigo_url) as coretigo_client:
        coretigo_sensor_nodes = [coretigo_client.get_node(d["nodeid"]) for d in active_bridges]
        while True:
            
            
            time.sleep(1)

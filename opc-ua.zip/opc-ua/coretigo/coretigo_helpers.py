from asyncua import Client
from iolink.iodd import IODD
import logging


async def find_active_nodes(url):
    master_branches = ["DeviceSet", "TigoMaster 2TH-EIP", "IOLinkWirelessMaster"]
    bridge_branches = ["Device", "General", "ProcessDataInput"]
    async with Client(url=url) as client:
        objects = client.get_objects_node()
        objects_node = await compare_browse_name(objects, master_branches[0])
        device_node = await compare_browse_name(objects_node, master_branches[1])
        master_node = await compare_browse_name(device_node, master_branches[2])

        bridge_node_names = [f"Port{i:0>2}" for i in range(16)]
        information_nodes = [(node, await node.read_browse_name()) for node in await master_node.get_children()]
        bridge_nodes = [node for node, browse_name in information_nodes if browse_name.Name in bridge_node_names]

        active_bridge_nodeids = []
        for bridge in bridge_nodes:
            device_node = await compare_browse_name(bridge, bridge_branches[0])
            if device_node is not None:
                general_node = await compare_browse_name(device_node, bridge_branches[1])
                data_node = await compare_browse_name(general_node, bridge_branches[2])

                model_node = await compare_browse_name(device_node, "Model")
                sensor_name = await model_node.read_value()

                active_bridge_nodeids.append({"nodeid": data_node.nodeid.to_string(), "sensor": sensor_name.Text})
        return active_bridge_nodeids


async def compare_browse_name(main_node, input_browse_name):
    for node in await main_node.get_children():
        browse_name = await node.read_browse_name()
        if browse_name.Name == input_browse_name:
            return node

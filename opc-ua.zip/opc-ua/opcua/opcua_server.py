import asyncio
import logging
from typing import Any
from pprint import pprint

from asyncua import Server, Node, ua
from asyncua.common.methods import uamethod

server = Server()


@uamethod
async def add_variable(parent, parent_nodeid: str, nodeid: str, bname: str, val: str = None) -> None:
    """Add a variable as a child to specified parent node.
    
    # TODO: find out how to define the datatype
    
    """
    global server
    parent_node = server.get_node("ns=2;i=1")
    await parent_node.add_variable("ns=2;i=101010", bname="Test", val="Test")


@uamethod
async def multiply_async(parent, x, y):
    sleep_time = x * y
    print(f"Sleeping asynchronously for {x * y} seconds")
    await asyncio.sleep(sleep_time)

async def main(nsidx: int, num_connections: int = 16) -> None:
    """Setup an OPC-UA server with preconfigured """
    _logger = logging.getLogger("NNE-OPC-UA-Server")

    await server.init()
    server.set_endpoint("opc.tcp://192.168.10.10:4840/nne_unibio/server/")
    server.set_server_name("NNE Unibio OPC-UA Server")

    # setup our own namespace, not really necessary but should as spec
    # Left in for now until we figure out if this is actually necessary
    uri = "http://examples.freeopcua.github.io"
    idx = await server.register_namespace(uri)

    devices = await server.nodes.objects.add_object(idx, "Devices")
    await devices.add_variable("ns=6;i=909090", bname="added", val="much node wow")
    for i in range(1, num_connections + 1):
        # Adding Port object, which will host the name of the sensor connected to the
        # port as well as all its information points
        port = await devices.add_object(
            f"ns={nsidx};i=1{i:0>2}00", bname=f"Port{i:0>2}"
        )
        await port.add_variable(
            f"ns={nsidx};i=1{i:0>2}10", "SensorName", f"Sensor{i:0>2}"
        )  # Sensor name
        information_points = await port.add_object(
            f"ns={nsidx};i=1{i:0>2}20", "InformationPoints"
        )  # Information points

        names_node = await information_points.add_variable(
            f"ns={nsidx};i=1{i:0>2}21",
            "Names",
            ["My", "milkshake", "brings", "all", "the", "boys", "to", "the", "yard"],
        )
        await names_node.set_writable()
        values_node = await information_points.add_variable(
            f"ns={nsidx};i=1{i:0>2}22", "Values", None
        )
        await values_node.set_writable()
        lowerbound_node = await information_points.add_variable(
            f"ns={nsidx};i=1{i:0>2}23", "LowerBounds", None
        )
        await lowerbound_node.set_writable()
        upperbound_node = await information_points.add_variable(
            f"ns={nsidx};i=1{i:0>2}24", "UpperBounds", None
        )
        await upperbound_node.set_writable()
        units_node = await information_points.add_variable(
            f"ns={nsidx};i=1{i:0>2}29", "Units", None
        )
        await units_node.set_writable()
        _logger.debug(f"Added node tree Port{i:0>2} with all child nodes")

    inargx = ua.Argument()
    inargx.Name = "x"
    inargx.DataType = ua.NodeId(ua.ObjectIds.Int64)
    inargy = ua.Argument()
    inargy.Name = "y"
    inargy.DataType = ua.NodeId(ua.ObjectIds.Int64)
    inargstr = ua.Argument()
    inargstr.Name = "String"
    inargstr.DataType = ua.NodeId(ua.ObjectIds.String)
    await devices.add_method(idx, "multiply_async", multiply_async, [inargx, inargy], [])
    await devices.add_method(idx, "add_node_clientside", add_node_clientside, [inargstr], [])
    _logger.info("Starting server!")
    async with server:
        while True:
            await asyncio.sleep(1)


if __name__ == "__main__":
    asyncio.run(main(nsidx=6), debug=True)

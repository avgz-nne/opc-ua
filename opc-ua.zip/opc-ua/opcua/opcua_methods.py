import logging

from asyncua import Node
from asyncua.common.methods import uamethod

_logger = logging.getLogger("NNE-OPC-UA Server")


@uamethod
async def add_variable(parent, parent_nodeid: str, nodeid: str, bname: str, val: str = None) -> None:
    """Add a variable as a child to specified parent node.
    
    # TODO: find out how to define the datatype
    
    """
    global server
    parent_node = server.get_node("ns=2;i=1")
    await parent_node.add_variable("ns=2;i=101010", bname="Test", val="Test")
